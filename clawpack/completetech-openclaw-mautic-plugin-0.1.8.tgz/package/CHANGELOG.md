# Changelog

## 0.1.8 - 2026-05-26

- Added GitHub Actions OIDC trusted publishing for ClawHub.
- Added a manual ClawHub publish workflow that validates locally, then calls ClawHub's official reusable publish workflow.
- Updated the workflow to publish the ClawPack `.tgz` artifact through the official ClawHub reusable workflow.
- Documented trusted publisher configuration and verification.

## 0.1.7 - 2026-05-26

- Improved the README production setup section for cleaner ClawHub rendering.
- Replaced inline-code-heavy setup steps with a compact operator checklist table.

## 0.1.6 - 2026-05-26

- Improved the README console bridge section for clearer ClawHub rendering.
- Clarified that only the console-command tool requires the private bridge.

## 0.1.5 - 2026-05-26

- Improved the README security defaults section for clearer ClawHub rendering.
- Replaced code-pill-heavy lists with compact operator-focused tables.

## 0.1.4 - 2026-05-26

- Published through ClawHub's newer ClawPack npm-pack artifact path.
- Kept the existing `bundle-plugin` package family while uploading a `.tgz` ClawPack instead of legacy zip files.
- Updated readiness checks and publish wrapper to preserve the npm-pack artifact format.

## 0.1.3 - 2026-05-26

- Improved the ClawHub README page with clearer compatibility, production setup, and operator safety sections.
- Documented verification against Mautic Community 7.1.1, the latest GitHub release checked on 2026-05-26.

## 0.1.2 - 2026-05-26

- Improved the README security section for clearer ClawHub rendering and operator guidance.

## 0.1.1 - 2026-05-26

- Updated ClawHub release tags for better package discovery.
- Added matching package keywords and GitHub repository topics.
- Cleaned up the production README included in the published package.

## 0.1.0 - 2026-05-26

- Prepared the Mautic Control plugin for ClawHub readiness review.
- Added publishable package metadata, license, security policy, package checks, and runtime unit tests.
- Split pure runtime policy helpers into `lib/runtime.js` for test coverage.
- Changed production defaults so optional maintenance commands and workspace file access are disabled until explicitly enabled.
- Preserved the local Docker stack behavior through explicit stack configuration.
- Documented deployment requirements, console bridge security, threat model, and verification steps.
